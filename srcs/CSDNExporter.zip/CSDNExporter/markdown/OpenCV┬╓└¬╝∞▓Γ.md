


**目录**



[一、轮廓检测基础理论](#%E4%B8%80%E3%80%81%E5%9F%BA%E7%A1%80%E7%90%86%E8%AE%BA)

[1、轮廓概述](#1%E3%80%81%E8%BD%AE%E5%BB%93%E6%A6%82%E8%BF%B0)

[2、API介绍](#2%E3%80%81API%E4%BB%8B%E7%BB%8D)

[1、cv.findContours函数（查找轮廓）](#2%E3%80%81cv.findContours%E5%87%BD%E6%95%B0%EF%BC%88%E6%9F%A5%E6%89%BE%E8%BD%AE%E5%BB%93%EF%BC%89)

[2、cv.drawContours函数（画出轮廓）](#3%E3%80%81cv.drawContours%E5%87%BD%E6%95%B0%EF%BC%88%E7%94%BB%E5%87%BA%E8%BD%AE%E5%BB%93%EF%BC%89)



[检测轮廓并画出：（用二值图检测轮廓）](#%E6%A3%80%E6%B5%8B%E8%BD%AE%E5%BB%93%E5%B9%B6%E7%94%BB%E5%87%BA%EF%BC%9A%EF%BC%88%E7%94%A8%E4%BA%8C%E5%80%BC%E5%9B%BE%E6%A3%80%E6%B5%8B%E8%BD%AE%E5%BB%93%EF%BC%89)

[二、代码及效果](#%E4%BA%8C%E3%80%81%E4%BB%A3%E7%A0%81)

[三、轮廓检测的属性](#%E4%B8%89%E3%80%81%E8%BD%AE%E5%BB%93%E6%A3%80%E6%B5%8B%E7%9A%84%E5%B1%9E%E6%80%A7)

[1、画出单个轮廓](#1%E3%80%81%E7%94%BB%E5%87%BA%E5%8D%95%E4%B8%AA%E8%BD%AE%E5%BB%93)

[2、显示面积和周长](#2%E3%80%81%E6%98%BE%E7%A4%BA%E9%9D%A2%E7%A7%AF%E5%92%8C%E5%91%A8%E9%95%BF)

[代码及效果](#%E4%BB%A3%E7%A0%81%E5%8F%8A%E6%95%88%E6%9E%9C)

[四、近似轮廓](#%E5%9B%9B%E3%80%81%E8%BF%91%E4%BC%BC%E8%BD%AE%E5%BB%93)

[1、步骤](#1%E3%80%81%E6%AD%A5%E9%AA%A4)

[2、API](#2%E3%80%81API)

[3、实现](#3%E3%80%81%E5%AE%9E%E7%8E%B0)



[各精度的近似轮廓： ](#%E5%90%84%E7%B2%BE%E5%BA%A6%E7%9A%84%E8%BF%91%E4%BC%BC%E8%BD%AE%E5%BB%93%EF%BC%9A%C2%A0)

[五、边界矩形和外接圆](#%E4%BA%94%E3%80%81%E8%BE%B9%E7%95%8C%E7%9F%A9%E5%BD%A2%E5%92%8C%E5%A4%96%E6%8E%A5%E5%9C%86)

[1、边界矩形 ](#1%E3%80%81%E8%BE%B9%E7%95%8C%E7%9F%A9%E5%BD%A2%C2%A0)

[2、外接圆](#2%E3%80%81%E5%A4%96%E6%8E%A5%E5%9C%86)

[总代码](#%E6%80%BB%E4%BB%A3%E7%A0%81)

[参考资料](#%E5%8F%82%E8%80%83%E8%B5%84%E6%96%99)


# 一、轮廓检测基础理论


## 1、轮廓概述


**边缘和轮廓区别：边缘是零散的点，轮廓是整体。**

**在二值图中找轮廓。**



## 2、API介绍



### 1、cv.findContours函数（查找轮廓）


```python
contours, hierarchy = cv2.findContours(img,mode,method)
```

**参数： **

![图 1](../images/20210819172450303.png)


![图 2](../images/20210819172726924.png)

** 返回：**
**contours：轮廓**
**hierarchy：层级**

```python
# 1、根据二值图找到轮廓
    contours, hierarchy = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    # 轮廓      层级                               轮廓检索模式(推荐此)  轮廓逼近方法
```





### 2、cv.drawContours函数（画出轮廓）


```python
# 2、画出轮廓
    dst = cv.drawContours(img, contours, -1,                (0, 0, 255), 3)
    #                           轮廓     第几个(默认-1：所有)   颜色       线条厚度
```


# 


### 检测轮廓并画出：（用二值图检测轮廓）


```python
# 提取轮廓
def GetGontours():
    # 1、根据二值图找到轮廓
    contours, hierarchy = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    # 轮廓      层级                               轮廓检索模式(推荐此)  轮廓逼近方法

    # 2、画出轮廓
    dst = cv.drawContours(img, contours, -1,                (0, 0, 255), 3)
    #                           轮廓     第几个(默认-1：所有)   颜色       线条厚度

    cv.imshow('dst', dst)
```




#  二、代码及效果


```python
# 轮廓提取
import cv2 as cv

# 转二进制图像
def ToBinray():
    global imgray, binary
    # 1、灰度图
    imgray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    cv.imshow('imgray', imgray)

    # 2、二进制图像
    ret, binary = cv.threshold(imgray, 127, 255, 0)
    # 阈值 二进制图像
    cv.imshow('binary', binary)


# 提取轮廓
def GetGontours():
    # 1、根据二值图找到轮廓
    contours, hierarchy = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
    # 轮廓      层级                               轮廓检索模式(推荐此)  轮廓逼近方法

    # 2、画出轮廓
    dst = cv.drawContours(img, contours, -1,                (0, 0, 255), 3)
    #                           轮廓     第几个(默认-1：所有)   颜色       线条厚度

    cv.imshow('dst', dst)


if __name__ == '__main__':
    img = cv.imread('Resource/test11.jpg')
    cv.imshow('img', img)

    ToBinray()          #转二进制

    GetGontours()       #提取轮廓

    cv.waitKey(0)
```



![图 3](../images/20210820153953924.png)



![图 4](../images/20210820150238154.png)



![图 5](../images/20210819203934431.png)





![图 6](../images/20210819204029286.png)



![图 7](../images/2021081920431117.png)






# 三、轮廓检测的属性


## 1、画出单个轮廓


```python
# 画出第一个轮廓
    cnt = contours[0]
    dst = cv.drawContours(img, cnt, -1, (0, 0, 255), 3)
    cv.imshow('dst1', dst)
```



![图 8](../images/20210820152125673.png)


 
![图 9](../images/20210820154032692.png)






## 2、显示面积和周长


```python
# 获取轮廓面积
    area = cv.contourArea(cnt)
    print("轮廓面积：", area)

    # 周长（True表示合并）
    perimeter = cv.arcLength(cnt, True)
    print("轮廓周长：", perimeter)
```




## 代码及效果


```python
# 获取轮廓信息
def GetContours_Attrib():
    # 画出第一个轮廓
    cnt = contours[0]
    dst = cv.drawContours(img, cnt, -1, (0, 0, 255), 3)
    cv.imshow('dst1', dst)

    # 获取轮廓面积
    area = cv.contourArea(cnt)
    print("轮廓面积：", area)

    # 周长（True表示合并）
    perimeter = cv.arcLength(cnt, True)
    print("轮廓周长：", perimeter)
```



![图 10](../images/20210820152416779.png)






# 四、近似轮廓


## 1、步骤


>1、获取轮廓外围

>2、设置精度（从轮廓到近似轮廓的最大距离）

>3、获取近似轮廓

>4、绘制轮廓





## 2、API


```python
# 2、设置精度（从轮廓到近似轮廓的最大距离）
    epsilon = 0.03 * cv.arcLength(cnt, True)
    #                            轮廓  闭合轮廓还是曲线
```


```python
# 3、获取近似轮廓
    approx = cv.approxPolyDP(cnt, epsilon,          True)
    #                             近似度(这里为10%)   闭合轮廓还是曲线
```




## 3、实现


```python
# 轮廓近似
def GetApprox():
    # 1、取外围轮廓
    cnt = contours[0]

    # 2、设置精度（从轮廓到近似轮廓的最大距离）
    epsilon = 0.05 * cv.arcLength(cnt, True)
    #                            轮廓  闭合轮廓还是曲线

    # 3、获取近似轮廓
    approx = cv.approxPolyDP(cnt, epsilon,          True)
    #                             近似度(这里为5%)   闭合轮廓还是曲线

    # 4、绘制轮廓
    draw_img = img.copy()
    res = cv.drawContours(draw_img, [approx], -1, (0, 0, 255), 3)

    # 显示
    cv.imshow("res", res)
```


### 


### 各精度的近似轮廓： 


精度**epsilon=0.01**时的近似轮廓： 


![图 11](../images/20210820160020922.png)


精度**epsilon=0.02**时的近似轮廓：


![图 12](../images/20210820155605982.png)
精度**epsilon=0.03**时的近似轮廓：


![图 13](../images/20210820155713768.png)


精度**epsilon=0.04**时的近似轮廓：


![图 14](../images/20210820155750313.png)


 精度**epsilon=0.05**时的近似轮廓：


![图 15](../images/20210820155926555.png)




# 五、边界矩形和外接圆


**边界矩形：根据坐标、长宽绘制矩形。**
**外接圆：根据圆心坐标、半径绘制圆。**


## 1、边界矩形 


```python
# 获取边界矩形
def BoundingRect():
    # 1、取外围轮廓
    cnt = contours[0]

    # 2、获取正方形坐标长宽
    x, y, w, h = cv.boundingRect(cnt)

    # 3、画出矩形
    dst = img.copy()
    dst = cv.rectangle(dst, (x,y),(x+w,y+h), (0,0,255), 3)

    # 显示
    cv.imshow("dst", dst)
```



![图 16](../images/20210820163635792.png)




## 2、外接圆


```python
# 获取外接圆
def Circle():
    # 1、获取第一个轮廓
    cnt = contours[0]

    # 2、获取外接圆
    (x, y), radius = cv.minEnclosingCircle(cnt)
    # 坐标   半径

    # 3、画圆
    dst = img.copy()
    dst = cv.circle(dst, (int(x), int(y)), int(radius), (0, 0, 255), 3)

    # 显示
    cv.imshow("dst", dst)
```



![图 17](../images/20210820164048267.png)




# 总代码


```python
# 轮廓提取、属性、近似轮廓、边界矩形和外接圆
import cv2 as cv

# 转二进制图像
def ToBinray():
    global imgray, binary
    # 1、灰度图
    imgray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    cv.imshow('imgray', imgray)

    # 2、二进制图像
    ret, binary = cv.threshold(imgray, 127, 255, 0)
    # 阈值 二进制图像
    cv.imshow('binary', binary)


# 提取轮廓
def GetContours():
    global contours
    # 1、根据二值图找到轮廓
    contours, hierarchy = cv.findContours(binary, cv.RETR_TREE, cv.CHAIN_APPROX_NONE)
    # 轮廓      层级                               轮廓检索模式(推荐此)  轮廓逼近方法

    # 2、画出轮廓
    dst = img.copy()
    dst = cv.drawContours(dst, contours, -1,                (0, 0, 255), 3)
    #                           轮廓     第几个(默认-1：所有)   颜色       线条厚度

    cv.imshow('contours', dst)


# 获取轮廓信息
def GetContours_Attrib():
    # 画出第一个轮廓
    cnt = contours[0]
    dst = img.copy()
    dst = cv.drawContours(dst, cnt, -1, (0, 0, 255), 3)
    cv.imshow('contour0', dst)

    # 获取轮廓面积
    area = cv.contourArea(cnt)
    print("轮廓面积：", area)

    # 周长（True表示合并）
    perimeter = cv.arcLength(cnt, True)
    print("轮廓周长：", perimeter)


# 轮廓近似
def GetApprox():
    # 1、取外围轮廓
    cnt = contours[0]

    # 2、设置精度（从轮廓到近似轮廓的最大距离）
    epsilon = 0.01 * cv.arcLength(cnt, True)
    #                            轮廓  闭合轮廓还是曲线

    # 3、获取近似轮廓
    approx = cv.approxPolyDP(cnt, epsilon,          True)
    #                             近似度(这里为5%)   闭合轮廓还是曲线

    # 4、绘制轮廓
    dst = img.copy()
    dst = cv.drawContours(dst, [approx], -1, (0, 0, 255), 3)

    # 显示
    cv.imshow("apporx", dst)


# 获取边界矩形
def BoundingRect():
    # 1、取外围轮廓
    cnt = contours[0]

    # 2、获取正方形坐标长宽
    x, y, w, h = cv.boundingRect(cnt)

    # 3、画出矩形
    dst = img.copy()
    dst = cv.rectangle(dst, (x,y),(x+w,y+h), (0,0,255), 3)

    # 显示
    cv.imshow("rect", dst)


# 获取外接圆
def Circle():
    # 1、获取第一个轮廓
    cnt = contours[0]

    # 2、获取外接圆
    (x, y), radius = cv.minEnclosingCircle(cnt)
    # 坐标   半径

    # 3、画圆
    dst = img.copy()
    dst = cv.circle(dst, (int(x), int(y)), int(radius), (0, 0, 255), 3)

    # 显示
    cv.imshow("circle", dst)


if __name__ == '__main__':
    img = cv.imread('Resource/contour.jpg')
    cv.imshow('img', img)

    ToBinray()              #转二进制

    GetContours()           #提取轮廓

    GetContours_Attrib()    #获取轮廓信息

    GetApprox()             #轮廓近似

    BoundingRect()          #边界矩形

    Circle()                #外接圆

    cv.waitKey(0)
```






# 参考资料


[https://www.bilibili.com/video/BV1PV411774y?p=25](https://www.bilibili.com/video/BV1PV411774y?p=25)

[http://woshicver.com/FifthSection/4_9_2_%E8%BD%AE%E5%BB%93%E7%89%B9%E5%BE%81/](http://woshicver.com/FifthSection/4_9_2_%E8%BD%AE%E5%BB%93%E7%89%B9%E5%BE%81/)

