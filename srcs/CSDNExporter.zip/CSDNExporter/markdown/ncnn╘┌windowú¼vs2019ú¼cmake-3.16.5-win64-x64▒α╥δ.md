

## 下载cmake，安装


cmake-3.16.5-win64-x64链接地址:[https://github.com/Kitware/CMake/releases/download/v3.16.5/cmake-3.16.5-win64-x64.zip](https://github.com/Kitware/CMake/releases/download/v3.16.5/cmake-3.16.5-win64-x64.zip)

+ 下载cmake到D:\cmake\文件夹下，并解压到此目录下 
![图 1](../images/20200417103128480.png)

+ 把bin目录添加到本机环境变量，鼠标右击 此电脑->高级系统设置（左边）->环境变量->选择path(用户变量)->编辑 
![图 2](../images/20200417103621989.png)

+ 再次进入D:\cmake\cmake-3.16.5-win64-x64\bin，右击cmake-gui.exe，发送到桌面快捷方式



## 下载protobuf，并编译


+ 链接地址:[https://github.com/protocolbuffers/protobuf/releases](https://github.com/protocolbuffers/protobuf/releases) 
![图 3](../images/2020041710414248.png)

+ 解压文件，并在解压文件同目录下添加文件夹protobuf-3.11.4-build-vs2019，如下： 
![图 4](../images/20200417104529845.png)

+ 编译protobuf 打开cmake-gui，选择源文件夹下的cmake，和新建的文件夹，如下所示 
![图 5](../images/20200417104817777.png)
 configure，主要要选择Visual Studio 16 2019 
![图 6](../images/20200417105105890.png)





![图 7](../images/20200417120834138.png)
 Generate后，在文件夹protobuf-3.11.4-build-vs2019生成如下文件 
![图 8](../images/20200417105610923.png)
 点击cmake下面的Open Project，进行编译，注意要选择Release，x64,右击INSTALL，点击生成
![图 9](../images/20200417105859155.png)
 编译后如下， 表示编译成功


![图 10](../images/20200417112346211.png)


在文件夹protobuf-3.11.4-build-vs2019，会生成install文件夹，里面如下


![图 11](../images/20200417112516309.png)


## 编译ncnn


+  ncnn地址： [https://github.com/Tencent/ncnn](https://github.com/Tencent/ncnn) 新建ncnn目录 git clone https://github.com/Tencent/ncnn.git到ncnn目录 
+  编译ncnn 打开vs2019自带的cmd，并且以管理员身份运行 
![图 12](../images/20200417113457174.png)
 



opencv 已安装 mkdir ncnn-build-vs2019 cd ncnn-build-vs2019 cmake -G"NMake Makefiles" -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=D:/GIT/ncnn-build-vs2019/install -DProtobuf_INCLUDE_DIR=D:\GIT\protobuf-3.11.4-build-vs2019\install\include -DProtobuf_LIBRARIES=D:\GIT\protobuf-3.11.4-build-vs2019\install\lib/libprotobuf.lib -DProtobuf_PROTOC_EXECUTABLE=D:\GIT\protobuf-3.11.4-build-vs2019\install\bin/protoc.exe -DNCNN_VULKAN=OFF -DOpenCV_DIR=D:/opencv/build D:/GIT/ncnn 
![图 13](../images/20200417113941945.png)


nmake 
![图 14](../images/20200417114508736.png)
 nmake install 
![图 15](../images/20200417114545428.png)
 ncnn编译完成，文件夹ncnn-build-vs2019下生成install文件夹 
![图 16](../images/20200417114723775.png)


## ncnn例子测试


+  打开vs2019,新建项目 
+  右击项目->属性->配置属性->VC++目录， 包含目录添加：D:\opencv\build\include;D:\GIT\protobuf-3.11.4-build-vs2019\install\include;D:\GIT\ncnn-build-vs2019\install\include\ncnn 库目录添加：D:\opencv\build\x64\vc15\lib;D:\GIT\protobuf-3.11.4-build-vs2019\install\lib;D:\GIT\ncnn-build-vs2019\install\lib 
+  配置属性->连接器->输入 附件依赖项： opencv_world411.lib ncnn.lib libprotobuf.lib 
+  测试 拷贝mobilenetssd.cpp,链接:[https://github.com/Tencent/ncnn/blob/master/examples/mobilenetssd.cpp](https://github.com/Tencent/ncnn/blob/master/examples/mobilenetssd.cpp) 



执行结果如下： 
![图 17](../images/20200417115810113.png)


